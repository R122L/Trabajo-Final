La versión de OWASP Juice Shop se identificó accediendo de forma autorizada
al contenedor Docker desplegado en el host Windows. Dado que el contenedor
no dispone de un intérprete de comandos estándar, la extracción de la versión
se realizó directamente mediante el runtime de Node.js, leyendo el campo
"version" del fichero /juice-shop/package.json.
