# Entorno experimental

## Sistema anfitrión
- Sistema operativo: Windows
- Virtualización: VirtualBox

## Máquina atacante
- Sistema operativo: Kali Linux (imagen oficial)
- Recursos asignados: 12 GB RAM, 5 vCPU
- Usuario: kali
- Arquitectura: amd64

## Red
- Interfaz NAT: acceso a Internet
- Interfaz Host-Only: comunicación con laboratorios
- Aislamiento: sin exposición a red externa

## Tecnologías empleadas
- Docker / Docker Compose
- OWASP Juice Shop
- VAmPI (Vulnerable API)

## Consideraciones éticas
Todas las pruebas se realizan exclusivamente sobre entornos deliberadamente vulnerables y controlados, sin afectar a sistemas reales ni de terceros.
